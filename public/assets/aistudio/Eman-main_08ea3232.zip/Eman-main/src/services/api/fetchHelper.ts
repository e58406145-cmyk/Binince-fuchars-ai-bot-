/**
 * Resilient fetch helper for crypto exchange public REST endpoints
 * Tries direct public URL first, falls back seamlessly to Vite reverse-proxy
 */

export async function fetchWithFallback<T>(directUrl: string, proxyPath: string): Promise<T> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 8000);

  // Strategy 1: Try direct URL first
  try {
    const res = await fetch(directUrl, {
      signal: controller.signal,
      headers: {
        'Accept': 'application/json',
      },
    });
    clearTimeout(timeoutId);
    if (res.ok) {
      return (await res.json()) as T;
    }
  } catch (err) {
    clearTimeout(timeoutId);
    // Silent fallback to proxy
  }

  // Strategy 2: Fallback to local reverse-proxy path
  const fallbackController = new AbortController();
  const fallbackTimeoutId = setTimeout(() => fallbackController.abort(), 8000);

  try {
    const res = await fetch(proxyPath, {
      signal: fallbackController.signal,
      headers: {
        'Accept': 'application/json',
      },
    });
    clearTimeout(fallbackTimeoutId);
    if (res.ok) {
      return (await res.json()) as T;
    }
    throw new Error(`Proxy response error status: ${res.status}`);
  } catch (err) {
    clearTimeout(fallbackTimeoutId);
    throw err;
  }
}
